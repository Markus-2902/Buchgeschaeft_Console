﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookstoreLibrary
{
    enum Category : int
    {
        History = 10,
        Thriller = 20,
        Fantasy = 30,
        Food = 40,
        Children = 50
    }
}
